<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Jon Layout Demo</title>
    
    <script type="text/javascript" src="js/jquery-1.6.4.js"></script>
	<script type="text/javascript" src="js/jquery.ui.all.js"></script>
	<script type="text/javascript" src="js/jquery.layout.js"></script>
    
	<script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
	
	<script type="text/javascript" src="js/layoutloader.js"></script>
    <script type="text/javascript" src="js/dashupdater.js"></script>
	
	
	<link rel="stylesheet" type="text/css" href="css/dashbasic.css" />
	<link rel="stylesheet" type="text/css" href="css/simpleappearancedem.css" />
	<link rel="stylesheet" type="text/css" href="css/mapstyler.css" />

</head>
<body>

<?php include 'htms/north.php';?>
<?php include 'htms/west.php';?>
<?php include 'htms/south.php';?>
<?php include 'htms/east.php';?>
<?php include 'htms/center.php';?>


</body>
</html>
