 function updateLeftPanel()
    {
        
        var iLastDateFound = 0;
        
		var request = $.ajax({
			url: "./phps/locman.php?fn=updatewest",
			type: "GET",			
			dataType: "html",
			async: true
		});

		request.done(function(msg)
        {
            alert('Got => ' + msg );
			//$("#mybox").html(msg);
            HandleJSONLocationsFromDB(msg);			
		});

		request.fail(function(jqXHR, textStatus) {
			alert( "Request failed: " + textStatus );
		});
	}
    
    
    function HandleJSONLocationsFromDB(jdata)
    {
        alert("JSON Data to extract from: \n" + jdata);
        var obj = JSON.parse(jdata);
        var iCnt = Object.keys(obj).length; //Object.keys(obj.[0]).length
        alert("COUNT OF ITEMS IN Json = " + iCnt);
        
        var xObj = obj[0];
        
        alert("Obj 1 = " + xObj);
        alert("Obj 1 UserID = " + xObj.userid);
        alert("Obj 1 Lat = " + xObj.lat);
        alert("Obj 1 Lon = " + xObj.lon);
        alert("Obj 1 Resp = " + xObj.responded);
        alert("Obj 1 Clsd = " + xObj.closed);
        
    }
   
   /* 
    function HandleJSONLocationsFromDB(jdata)
    {
        alert(jdata);
        var obj = JSON.parse(jdata);
        var iCnt = Object.keys(obj).length; //Object.keys(obj.[0]).length
        alert(iCnt);
        //alert(obj['userid']);
        
//        var subObj = obj[0];
        
//        alert("" + subObj['userid']);
        
        
        for (a =0; a < Object.keys(obj).length; a++)
        {
            alert("JK::: " + Object.keys(obj)[a] + " -> " + obj[Object.keys(obj)[a]]);
        }
        
        var x = obj.location;
        
        var result = [];
        var keys = Object.keys(x);
        keys.forEach(function(key){
            result.push(x[key]);
            alert("__+_ " + x[key]);
        });
        
        
        alert("TYPE = " + obj.location.constructor.toString());
        alert(x.length);
        alert(Object.keys(x)[0]);
        alert(x[0]);
    }
*/
    function AddNewTableRow()
    {
        
    }
