<div class="ui-layout-west">


    <input type="button" value="Update West Panel" onclick="updateLeftPanel()" />
	
		<?php
		//include("phps/locman.php");
		//GetLatitudeLongitudeLast20();
		?>
	
	<p><button onclick="myLayout.close('west')">Close Me</button></p>

	<p><a href="#" onClick="showOptions(myLayout,'defaults.fxSettings_open');showOptions(myLayout,'west.fxSettings_close')">Show Options.Defaults</a></p>
	
</div>

