<?php

/**
 * @author Jon0
 * @copyright 2016
 */
 
 class LocationPopulation
 {
    public $varLatitude;
    public $varLongitude;
    public $varUserID;
    public $varHasResponded;
    public $varHasClosed; 
}

?>