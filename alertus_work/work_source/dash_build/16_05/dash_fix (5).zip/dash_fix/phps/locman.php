<?php

/**
 * @author Jon0
 * @copyright 2016
 */

$servername = "localhost";
$username = "root";
$password = "toor";
$dbname = "testdb";


include_once("locationpopulations.php"); //COntains classer

GetFunctionToCall(); //Do Check for Function Action

function GetFunctionToCall()
{
    if (!isset( $_REQUEST["fn"] ))
	{
		echo "Action Not Set";
			return;
	}
    $funcID = $_REQUEST["fn"];
    
    if ($funcID == "add")
    {
        AddLatitudeLongitude();
    }
    else
    if ($funcID == "get")
    {
        GetLatitudeLongitudeLast20();
    }
    else
    if ($funcID == "updatewest")
    {
        GetLatitudeLongitudeLast50();
    }
}




function GetLatitudeLongitudeLast20()
{
      //$myname = test_data($_REQUEST["name"]);
      //$mypswd = test_data($_REQUEST["password"]);
     
    global $servername, $username, $password, $dbname;
     
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
    }

    $tableName = "user_loc";
    $tblDateField = "date";
    $tblLoadLimit = 30;
 
	$userID = 1;
	//$userID = $_REQUEST['userid'];


//    $stmt = $conn->prepare("SELECT * FROM $tableName WHERE userid = ?");
    $stmt = $conn->prepare("SELECT * FROM $tableName WHERE userid = ? ORDER BY date DESC LIMIT $tblLoadLimit");
    $stmt->bind_param("s", $userID);
    $stmt->execute();
    
    /* <!-------------    PROCESSING     ------------> */
    $result = $stmt->get_result();
    
	
    $return_array = null;
    
    while ($row = $result->fetch_assoc())
    {
		
		 $sTMP = "";
        $return_array = $row;
        $sTMP .= "Lat: " . $row["latitude"] . ",";
        $sTMP .= "Lon: " . $row["longitude"] . "<br>";
		$sID = $row["userid"] . "<br>";
		$sHasRespond = $row["hasresponded"] . "<br>";
		$sHasClosed = $row["hasclosedcase"] . "<br>";
		
		testTable($sTMP, $sID, $sHasRespond, $sHasClosed);
    }
    
   // echo "RESULTS ::: <br>" . $sTMP;
}


function AddLatitudeLongitude()
{
    ////
      $dateCreated = time();
      $sUserID = $_REQUEST["userid"];
      $sLatitude = $_REQUEST["latitude"];
      $sLongitude = $_REQUEST["longitude"];
      $sHasResponded = "0"; //test_data($_REQUEST["hasresponded"]);
      $sHasClosedCase = "0"; //test_data($_REQUEST["hasclosedcase"]);
    ////
    
    global $servername;
    global $username;
    global $password;
    global $dbname;
      
    echo "Connecting to: " . $servername;
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn)
    {
     die("Connection failed: " . mysqli_connect_error());
    }
    
   /////// $stmt = $conn->prepare("SELECT * FROM $tableName WHERE userid = ? ORDER BY $date DESC LIMIT $tblLoadLimit");
    
    $tableName = "user_loc";

	$sAddLocation = $conn->prepare("INSERT INTO ". $tableName . " (userid, date, latitude, longitude, hasresponded, hasclosedcase) VALUES ( ?, ?, ?, ?, ?, ? )");
    
    if ($sAddLocation)
    {
	   $sAddLocation->bind_param("iiddii", $sUserID, $dateCreated, $sLatitude, $sLongitude, $sHasResponded, $sHasClosedCase);
  
   	if (!$sAddLocation->execute())
	{
		echo "Failed to add Location...";
		echo "Execute failed: (" . $sAddLocation->errno . ") " . $sAddLocation->error;
	}else{
		echo "Successfully added Location...";
	}
       
       //$result = $sAddLocation->get_result();
       //if ($result)
       //{
//		$return_array = $result->fetch_array();
		
//    		if (!$return_array)
 //   		{
 //   			echo "<br>OK ... did add<br>";
  //  			$sAddLocation->close();
 //           }
        }
       // else
      //  {
      //      echo "<br>No Results<br>";
     //   }
    //}
    //else
   // {
   // 	trigger_error('Statement failed : ' . mysqli_stmt_error($sCheckExist), E_USER_ERROR);
   // }    
    mysqli_close($conn);
}

function testTable($slocation, $suserID, $sHasRespond, $sHasClosed) {
	
	$blocks ="<div id = \"block\">
			<div id= \"personname\">
				User ID: $suserID
			</div>
			<div id = \"contactdetails\">
			Contact: 653416541
			</div>
			<div id = \"location\">
				Location: $slocation
			</div>
			<div id = \"fourth\">
				Case Response: $sHasRespond 
				</div>
			<div id = \"fifth\">
				Case Closed:  $sHasClosed
			</div>
		</div><br>";
		
		
		// for ( $a = 0; $a <  20; $a++) {
			  echo $blocks;
			  
		// }
}

function locationDrop ($slocation, $sID, $sHasRespond, $sHasClosed) {
	$locationDrop = " 	var myLatLngZ = {$slocation};	
						var marker3 = new google.maps.Marker({
							position: myLatLngZ,
							map: map,
							draggable: false,
							animation: google.maps.Animation.DROP,
							title: 'Hello World!@!@!!'
						});
						
						marker3.addListener('click', toggleBounce);
								
						function toggleBounce() {
							if (marker3.getAnimation() !== null) {
								marker3.setAnimation(null);
							} else {
								marker3.setAnimation(google.maps.Animation.BOUNCE);
							}
						}
					";
			print $locationDrop;				
}


/////////////////////////////

function GetLatitudeLongitudeLast50()
{
    /*
    Parameters Required:
       GetFunctionToCall -> 'updatewest'
       this -> 'lastdate' [Optional, otherwise loads since beginning of time & 50 items]
    */
    
    global $servername, $username, $password, $dbname;
     
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
    }

    $tableName = "user_loc";
    $tblDateField = "date";
    $tblLoadLimit = 50;
 
	$userID = 1;
	//$userID = $_REQUEST['userid'];

/*
SELECT * 
  FROM TABLENAME 
 WHERE [DateTime] >= '2011-04-12 12:00:00 AM'
   AND [DateTime] <= '2011-05-25 3:35:04 AM'
*/

//Depending on the country setting for the login, the month/day may need to be swapped around  ??? [not sure]

$lastObtainedDate = null;

if (isset($_REQUEST['lastdate']))
{
    $lastObtainedDate = $_REQUEST['lastdate'];
    
    $lastObtainedDate = Date1970ToYYMMDD($lastObtainedDate);
}
else
{
    $lastObtainedDate = '2016-05-01 23:00:00 AM'; //1461529814
}

//    $stmt = $conn->prepare("SELECT * FROM $tableName WHERE userid = ?");
    $stmt = $conn->prepare("SELECT * FROM $tableName WHERE date > '$lastObtainedDate' ORDER BY date DESC LIMIT $tblLoadLimit");
    
    //$stmt = $conn->prepare("SELECT * FROM $tableName ORDER BY date DESC LIMIT $tblLoadLimit");
    //$stmt->bind_param("s", $userID);
    $stmt->execute();
    
    /* <!-------------    PROCESSING     ------------> */
    $result = $stmt->get_result();
    
    $return_array = null;
    
    $iNumRows = mysqli_num_rows($result);  // int mysql_num_rows ( resource $result )
    $empty_arr = array_fill(0, $iNumRows, NULL);
	
    $iLoop = 0;
    
    while ($row = $result->fetch_assoc())
    {
		$locPop = new LocationPopulation;
        
        $locPop->varLatitude = $row["latitude"];
        $locPop->varLongitude = $row["longitude"];
        $locPop->varUserID = $row["userid"];
        $locPop->varHasResponded = $row["hasresponded"];
        $locPop->varHasClosed = $row["hasclosedcase"]; 
        
        $empty_arr[$iLoop] = $locPop;
        
        $iLoop++;
        
        /*
		 $sTMP = "";
        $return_array = $row;
        $sTMP .= "Lat: " . $row["latitude"] . ",";
        $sTMP .= "Lon: " . $row["longitude"] . "<br>";
		$sID = $row["userid"] . "<br>";
		$sHasRespond = $row["hasresponded"] . "<br>";
		$sHasClosed = $row["hasclosedcase"] . "<br>";
		
		testTable($sTMP, $sID, $sHasRespond, $sHasClosed);
        */
    }
    
    $sJSONBuild = "";
    
//    for ($a = 0; $a < 1; $a++); //count($empty_arr); $a++)
    for ($a = 0; $a < count($empty_arr); $a++)
    {
        $x = $empty_arr[$a];
        /*
        echo "<br><br>This has been obtained by the DB and is now Classed<br><br>";
        echo "<br> Lat -> " . $x->varLatitude . "<br>";
        echo "<br> Lon -> " . $x->varLongitude . "<br>";
        echo "<br> UID -> " . $x->varUserID . "<br>";
        echo "<br> HaR -> " . $x->varHasResponded . "<br>";
        echo "<br> HaC -> " . $x->varHasClosed . "<br>";
        echo "<br><br>Ta fucking Dah!<br><br>";
        */
        $vJSONMake = JSONmaker($x->varUserID, $x->varLatitude, $x->varLongitude, $x->varHasResponded, $x->varHasClosed);
        
        if ($a < count($empty_arr) - 1)
        {
            $vJSONMake .= ",";
        }
        //echo $vJSONMake;
        $sJSONBuild .= $vJSONMake;
    }
    $sJSONBuild = "[" . $sJSONBuild . "]";
    echo $sJSONBuild;
}


function Date1970ToYYMMDD($date1970)
{
     date_default_timezone_set('Africa/Johannesburg'); 
     $dStr = date("Y-m-d h:i:s A", $date1970);
     
     return $dStr;
}


function JSONmaker($uid, $lat, $lon, $hasresp, $hasclosed)
{	
		$thisString = '{"userid":"' . $uid . '","lat":"' . $lat . '","lon":"' . $lon . '","responded":"' . $hasresp . '","closed":"' . $hasclosed . '"}';
		return $thisString;  //Add this back after it works 
        
        //CHEAT -->
  //      echo '[{"userid":"0","lat":"22.7777","lon":"-5.6666","responded":"0","closed":"0"},{"userid":"1","lat":"23.8888","lon":"-4.5555","responded":"0","closed":"0"},{"userid":"1","lat":"21.9999","lon":"-3.6666","responded":"0","closed":"0"}]';
}

?>