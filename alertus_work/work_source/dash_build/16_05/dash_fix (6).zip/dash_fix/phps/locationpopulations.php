<?php

/**
 * @author Jon0
 */
 
 class LocationPopulation
 {
    public $varLatitude;
    public $varLongitude;
    public $varUserID;
    public $varHasResponded;
    public $varHasClosed; 
}

?>