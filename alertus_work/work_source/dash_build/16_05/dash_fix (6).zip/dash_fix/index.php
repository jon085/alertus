<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Jon Layout Demo</title>
    
    
    <script type="text/javascript" src="js/jquery-1.6.4.js"></script>
    
    <!--  This doesn't allow ajax php call, but allows windows to drag... 1.6.4 doesn't allow window dragging -->
    <!--
    <script type="text/javascript" src="js/jquery-old.js"></script>
    -->
    
	<script type="text/javascript" src="js/jquery.ui.1.9.2.js"></script>
	<script type="text/javascript" src="js/jquery.layout-1.3.0.rc30.80.js"></script>
    
	<script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
	
	<script type="text/javascript" src="js/layoutloader.js"></script>
    <script type="text/javascript" src="js/dashupdater.js"></script>
	
	
	<link rel="stylesheet" type="text/css" href="css/dashbasic.css" />
	<link rel="stylesheet" type="text/css" href="css/simpleappearancedem.css" />
	<link rel="stylesheet" type="text/css" href="css/mapstyler.css" />

</head>
<body>

<?php include 'htms/north.php';?>
<?php include 'htms/west.php';?>
<?php include 'htms/south.php';?>
<?php include 'htms/east.php';?>
<?php include 'htms/center.php';?>


</body>
</html>
