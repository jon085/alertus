<div class="ui-layout-center">
	<div id = "map">
		<!--Google maps requires a page element in which to appear-->
	</div> 
</div>

