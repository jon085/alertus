<div class="ui-layout-east">
	This is the east pane, closable, slidable and resizable

	<!-- attach allowOverflow method to this specific element -->
	<ul onmouseover="myLayout.allowOverflow(this)" onmouseout="myLayout.resetOverflow('east')">
		<li>
			<ul>
				<li>one</li>
				<li>two</li>
				<li>three</li>
				<li>four</li>
				<li>five</li>
			</ul>
			Pop-Up <!-- put this below so IE and FF render the same! -->
		</li>
	</ul>

	<p><button onclick="myLayout.close('east')">Close Me</button></p>
	
	<button onclick="myFunction()">Try it</button>

<table id="myTable">
  <!--<tr>
    <td>Row1 cell1</td>
    <td>Row1 cell2</td>
  </tr>-->
</table>
<br>

<button onclick="myFunction()">Try it</button>

</div>

