 function updateLeftPanel()
    {
        
        var iLastDateFound = 0;
        
		var request = $.ajax({
			url: "./phps/locman.php?fn=updatewest",
			type: "GET",			
			dataType: "html",
			async: true
		});

		request.done(function(msg)
        {
            alert('Got => ' + msg );
			//$("#mybox").html(msg);
            HandleJSONLocationsFromDB(msg);			
		});

		request.fail(function(jqXHR, textStatus) {
			alert( "Request failed: " + textStatus );
		});
	}
    
    function HandleJSONLocationsFromDB(jdata)
    {
        var obj = JSON.parse(jdata);
        var iCnt = obj.length; //Object.keys(obj.[0]).length
        alert(iCnt);
    }

    function AddNewTableRow()
    {
        
    }
