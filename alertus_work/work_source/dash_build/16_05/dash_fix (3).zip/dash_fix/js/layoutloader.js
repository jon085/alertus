var myLayout;

	$(document).ready(function ()
	{
		myLayout = $('body').layout({
			// enable showOverflow on west-pane so popups will overlap north pane
			//west__showOverflowOnHover: true
			
		//,	west__fxSettings_open: { easing: "easeOutBounce", duration: 750 }
		});
		
		
		//setInterval("myFunction()", 2000);
        
        //setInterval("updateLeftPanel()", 2000);
		 
		 initializeMap();
 	});
	

	
	function myFunction()
	{
		var table = document.getElementById("myTable");
		var row = table.insertRow(0);
		var cell1 = row.insertCell(0);
		cell1.innerHTML = "<div id = \"block\"><div id= \"personname\">Name: Ben</div><div id = \"contactdetails\">Contact: 653416541</div><div id = \"location\">Location: Lat: 21.7768,Lon: -4.6659<br></div><div id = \"fourth\">Fillme1:</div>";
	}

	
	function initializeMap()
	{
		var locations = [
		  ['Bondi Beach', -26.04, 28.12, 2],
		  ['Coogee Beach', -26.05, 28.13, 1]
		];

		var map = new google.maps.Map(document.getElementById('map'), {
		  zoom: 10,
		  center: new google.maps.LatLng(-26.181977, 28.143859),
		  mapTypeId: google.maps.MapTypeId.ROADMAP
		});

		var infowindow = new google.maps.InfoWindow();

		var marker, i;

		for (i = 0; i < locations.length; i++) {  
		  marker = new google.maps.Marker({
			position: new google.maps.LatLng(locations[i][1], locations[i][2]),
			map: map
		  });

		  google.maps.event.addListener(marker, 'click', (function(marker, i) {
			return function() {
			  infowindow.setContent(locations[i][0]);
			  infowindow.open(map, marker);
			}
		  })(marker, i));
		}
	}
