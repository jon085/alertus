<?php

//Add User

$servername = "localhost";
$username = "root";
$password = "toor";
$dbname = "testdb";

$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
}

function test_data($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

  $sFirstname = test_data($_REQUEST["firstname"]);
  $sSurname = test_data($_REQUEST["surname"]);
  $sEmail = test_data($_REQUEST["email"]);
  $sPassword = test_data($_REQUEST["password"]);
  $sTelNum = test_data($_REQUEST["telnum"]);
  $sPrivilege = test_data($_REQUEST["privilege"]);
  
 //id, datecreate, firstname, surname, email, password, telnum, privilege

 $tableName = "master_users";
 $sCheckExist = $conn->prepare("SELECT * FROM ". $tableName . " WHERE firstname = ? AND surname = ? AND email = ? AND password = ?");
 
 if ($sCheckExist)
{
        $sCheckExist->bind_param("ssss", $sFirstname, $sSurname, $sEmail, $sPassword);
        $sCheckExist->execute();
		$result = $sCheckExist->get_result();
		$return_array = $result->fetch_array();
		
		if (!$return_array)
		{
			echo "User doesn't exist, hence can add them!";
			$sCheckExist->close();
			
			AddUserProtocol($conn, $sFirstname, $sSurname, $sEmail, $sPassword, $sTelNum, $sPrivilege);
		}
		else
		{
			echo "This user exists already";
			$sCheckExist->close();
		}
		
    mysqli_close($conn);
}
else
{
	trigger_error('Statement failed : ' . mysqli_stmt_error($sCheckExist), E_USER_ERROR);
}

function AddUserProtocol($connection, $siFirstname, $siSurname, $siEmail, $siPassword, $siTelNum, $siPrivilege)
{	
	$dateCreated = time();
	echo " ADDING:::: " . intval($dateCreated). " - " . $siFirstname. " - " . $siSurname. " - " . $siEmail. " - " . $siPassword. " - " . $siTelNum. " - " . intval($siPrivilege);
	
	$tableName = "master_users";

	$sAddUser = $connection->prepare("INSERT INTO ". $tableName . " (datecreate, firstname, surname, email, password, telnum, privilege) VALUES ( ?, ?, ?, ?, ?, ?, ? )");
	$sAddUser->bind_param("isssssi", $dateCreated, $siFirstname, $siSurname, $siEmail, $siPassword, $siTelNum, $siPrivilege);
	
	if (!$sAddUser->execute())
	{
		echo "Failed to add Credentials...";
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
	}else{
		echo "Successfully added Credentials...";
	}
	
	$sAddUser->close();
}


?>