<?php

/**
 * @author Jon0
 * @copyright 2016
 */

$servername = "localhost";
$username = "root";
$password = "toor";
$dbname = "testdb";


GetFunctionToCall(); //Do Check for Function Action

function GetFunctionToCall()
{
    if (!isset( $_REQUEST["fn"] ))
	{
		echo "Action Not Set";
			return;
	}
    $funcID = $_REQUEST["fn"];
    
    if ($funcID == "add")
    {
        AddLatitudeLongitude();
    }
    else
    if ($funcID == "get")
    {
        GetLatitudeLongitudeLast20();
    }
}


function GetLatitudeLongitudeLast20()
{
      //$myname = test_data($_REQUEST["name"]);
      //$mypswd = test_data($_REQUEST["password"]);
     
    global $servername, $username, $password, $dbname;
     
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
    }

    $tableName = "user_loc";
    $tblDateField = "date";
    $tblLoadLimit = 30;

    $userID = $_REQUEST["userid"];


//    $stmt = $conn->prepare("SELECT * FROM $tableName WHERE userid = ?");
    $stmt = $conn->prepare("SELECT * FROM $tableName WHERE userid = ? ORDER BY date DESC LIMIT $tblLoadLimit");

    $stmt->bind_param("s", $userID);
    $stmt->execute();
    
    /* <!-------------    PROCESSING     ------------> */
    $result = $stmt->get_result();
    
    $return_array = null;
    
    $sTMP = "";
    while ($row = $result->fetch_assoc())
    {
        $return_array = $row;
        $sTMP .= "Lat: " . $row["latitude"] . "&nbsp;&nbsp;-&nbsp;&nbsp;";
        $sTMP .= "Lon: " . $row["longitude"] . "<br>";
    }
    
    echo "RESULTS ::: <br>" . $sTMP;
}

function AddLatitudeLongitude()
{
    ////
      $dateCreated = time();
      $sUserID = $_REQUEST["userid"];
      $sLatitude = $_REQUEST["latitude"];
      $sLongitude = $_REQUEST["longitude"];
      $sHasResponded = "0"; //test_data($_REQUEST["hasresponded"]);
      $sHasClosedCase = "0"; //test_data($_REQUEST["hasclosedcase"]);
    ////
    
    global $servername;
    global $username;
    global $password;
    global $dbname;
    
    
    echo "Connecting to: " . $servername;
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn)
    {
     die("Connection failed: " . mysqli_connect_error());
    }
    
   /////// $stmt = $conn->prepare("SELECT * FROM $tableName WHERE userid = ? ORDER BY $date DESC LIMIT $tblLoadLimit");
    
    $tableName = "user_loc";

	$sAddLocation = $conn->prepare("INSERT INTO ". $tableName . " (userid, date, latitude, longitude, hasresponded, hasclosedcase) VALUES ( ?, ?, ?, ?, ?, ? )");
    
    if ($sAddLocation)
    {
	   $sAddLocation->bind_param("iiddii", $sUserID, $dateCreated, $sLatitude, $sLongitude, $sHasResponded, $sHasClosedCase);
   
   
   	if (!$sAddLocation->execute())
	{
		echo "Failed to add Location...";
		echo "Execute failed: (" . $sAddLocation->errno . ") " . $sAddLocation->error;
	}else{
		echo "Successfully added Location...";
	}
       
       //$result = $sAddLocation->get_result();
       //if ($result)
       //{
//		$return_array = $result->fetch_array();
		
//    		if (!$return_array)
 //   		{
 //   			echo "<br>OK ... did add<br>";
  //  			$sAddLocation->close();
 //           }
        }
       // else
      //  {
      //      echo "<br>No Results<br>";
     //   }
    //}
    //else
   // {
   // 	trigger_error('Statement failed : ' . mysqli_stmt_error($sCheckExist), E_USER_ERROR);
   // }
    
    mysqli_close($conn);
}


?>