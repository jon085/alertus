<?php
$servername = "localhost";
$username = "root";
$password = "toor";
$dbname = "tryme";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
}

  $myname = test_data($_REQUEST["name"]);
  $mypswd = test_data($_REQUEST["password"]);

function test_data($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

   $stmt = $conn->prepare("SELECT * FROM users WHERE name = ? AND password = ?");

if ($stmt)
{
	 echo (">>>>:: NAME: " . $myname . "  PASSWORD: " . $mypswd . "<br>");

        $stmt->bind_param("ss", $myname, $mypswd);
        $stmt->execute();
        
        $result = $stmt->get_result();
        
        $return_array = null;
		
//        while ($row = $result->fetch_assoc()) {  //Shouldn't need this due to only 1 result, user+pass should be unique
//            $return_array = $row;
//        }

		//$return_array = $result->fetch_assoc(); //Assoc only has indexes as Table Identifiers
		
		$return_array = $result->fetch_array();   //Array only has indexes as Table Identifiers and Array Indexes

     if (null != $return_array)
     {
        echo (">>> Username and Password Match!<br>");
        echo (">>> ROW CO: " . count($return_array) . "<br>");
		
		echo (">>> ROW CO>>: " . $return_array['id'] . "<br>");
		echo (">>> ROW CO>>: " . $return_array['name'] . "<br>");
		echo (">>> ROW CO>>: " . $return_array['password'] . "<br>");
		
		echo (">>> ROW CO>>: " . $return_array[0] . "<br>");
		echo (">>> ROW CO>>: " . $return_array[1] . "<br>");
		echo (">>> ROW CO>>: " . $return_array[2] . "<br>");
		
		PassProcedure($myname, $mypswd);
     }
     else
     {
        echo (">>> ROW CO: " . "None Found!<br>");
		FailedProcedure();
     }

	$stmt->close();
}
else
{
	trigger_error('Statement failed : ' . mysqli_stmt_error($stmt), E_USER_ERROR);
}

mysqli_close($conn);

function FailedProcedure()
{
	session_start();
	
	$dAttemptCount = null;
	
	if (isset($_SESSION['failattempt']))
	{
	  $dAttemptCount = $_SESSION['failattempt'];
	}
	if (null == $dAttemptCount) $dAttemptCount = 0;
	$_SESSION['failattempt'] = ++$dAttemptCount;
	
	echo "THIS HAS FAILED $dAttemptCount time" . ($dAttemptCount == 1 ? "":"s") ."!!!";
}
function PassProcedure($sUsername, $sPassword)
{
    session_start();
	if (isset($_SESSION['failattempt']))
	{
	   unset($_SESSION['failattempt']);
	}
	
	session_destroy();
	session_start();

	$_SESSION["user_name"] = $sUsername;
    $_SESSION["user_password"] = $sPassword;

	echo "<br>PROCEDURE HAS SUCCEEDED with User: $sUsername and Pass: $sPassword<br>";


//	header("Location: http://www.google.com");
//echo "ENCR::: hello = " . md5("Hello");


    exit;
}

/*
function OutputStringArray($sstring)
{   
    if( is_array($sstring) )
    {
        echo "ARRAYV = " . $sstring;  
		foreach($sstring as $k=>$sVal){
			$sstring[$k] = _wp_specialchars( $sVal, $quote_style, $charset, $double_encode );
		}
		//return $sstring;
        echo $sstring;
    }
    else if (is_int($sstring))
    {
        echo "INT VAL = " . $sstring;        
    }
    else if (is_bool($sstring))
    {
        echo "BOOL VAL = " . ($sstring ? "TRUE!!":"FALSE!!");        
    }
    else if (is_string($sstring))
    {
        echo "String VAL = " . $sstring;        
    }
    else
    {
        echo "TYPE = " . gettype($sstring);
        echo "<br>CLASS = " . get_class($sstring);
    }
}
*/

?>
